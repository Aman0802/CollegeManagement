<html>
    <head>
	<title>
		homepage
	</title>
</head>
    <body>
        <link rel="stylesheet" type="text/css" href="indexxxxx.css">
    <div class="box">
        <div class="title">
            <img src="university-logo.png" alt="logo" width="150" height="150" class="1og">
            <h1>
                COLLEGE NAME
            </h1>
        </div>
        <div class="option">
            <img src="images/admin.png" alt="admin-logo" width="100" height="100" class="img">
            <img src="images/student.png" alt="student-logo" width="100" height="100" class="img"><br>
            <a href="admin_login/" class="btn">ADMIN</a>
            <div class="button">
            <a href="student_login/" class="btn">STUDENT</a>
            </div>
        </div>
    </div>
    </body>
</html>