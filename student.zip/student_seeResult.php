<html>
<head>
	<title></title>
</head>
<body>
    <link rel="stylesheet" type="text/css" href="css/seeresultcss.css">
	<h1>See Result</h1>
	<form action="" method="post" class="form">
		Enter the name of the exam
		<select name="cmbExamName" class="inputre">
            <option value selected disabled>Select An Option</option>
			<?php
				$con=mysqli_connect('localhost','root','','php_project');
				$qry="select distinct exam_name from result_table where id = 1";//$SESSION['userid']
				$rs=mysqli_query($con,$qry);
				while($row=mysqli_fetch_array($rs))
				{
					echo "<option value= '".$row['exam_name']."'>";
					echo $row['exam_name'];
					echo "<option>";
				}
			?>
		</select>
		<input type="submit" name="btnSubmit" value="Search" class="btn">
		<?php
			if(isset($_POST['btnSubmit']))
			{
				$exam_name=$_POST['cmbExamName'];
				$con=mysqli_connect('localhost','root','','php_project');
				$qry="select * from result_table where exam_name = '".$exam_name."' and id = 1";//$SESSION['userid']
				$rs=mysqli_query($con,$qry);	
				echo "<table border='1'>";
				echo "<tr>";
				echo "<th>CP&I</th>";
				echo "<th>ICSE</th>";
				echo "<th>Maths</th>";
				echo "<th>Physics</th>";
				echo "<th>Principles of C Language</th>";
				echo "<th>Web Developement</th>";
				echo "</tr>";
				while($row=mysqli_fetch_array($rs))
				{
					echo "<tr>";
					echo "<td><input type='text' name='txtcpi' value='".$row['cpi']."'></td>";
					echo "<td><input type='text' name='txticse' value='".$row['icse']."'></td>";
					echo "<td><input type='text' name='txtMaths' value='".$row['maths']."'></td>";
					echo "<td><input type='text' name='txtPhy' value='".$row['physics']."'></td>";
					echo "<td><input type='text' name='txtC' value='".$row['c']."'></td>";
					echo "<td><input type='text' name='txtHtml' value='".$row['html']."'></td>";
					echo "</tr>";
				}
				echo "</table>";
			}
		?>
	</form>
</body>
</html>