<html>
<head>
	<title>FAQs</title>
</head>
<body>
    <link rel="stylesheet" type="text/css" href="css/faqscss.css">
<center><h1>Previously Asked Questions</h1></center>
<div class="box">
    <h3>We recommend to go through these questions and try not to ask a redundant question.</h3>
<form action="student_askQues.php" method="post" class="form">
<table border="3" class="table">
<tr></tr>
<th>Query</th>
<th>Answer</th> 	
<?php
	session_start();
	$con=mysqli_connect('localhost','root','','php_project');
	$qry="select * from question where answer!='Not Answered'";
	$rs=mysqli_query($con,$qry);
	while($row=mysqli_fetch_array($rs))
	{
		echo "<tr>";
		echo "<td><input type='text' name='txtQues' value='".$row['question']."'></td>";
		echo "<td><input type='text' name='txtAns' value='".$row['answer']."'></td>";
		echo "</tr>";
	}
?>
</table><br><br><br><br>
<input type="submit" name="btnSubQuery" value="Ask for a new Question" class="btn">
<input type="button" name="btnOkay" value="Okay , Got my Answer!" class="btn">

<?php
	if(isset($_POST['btnOkay']))
	{
		header("location:student_welcome.php");
	}
?>
</form>
</div>
</body>
</html>