<html>
<head>
	<title></title>
</head>
<body>
    <link rel="stylesheet" type="text/css" href="css/asknewq.css">
    <div class="box">
<h1>Ask a Question</h1>
<form method="post" class="form">
<h3>Question:</h3>	
<input type="char" name="txtQues" class="inputre"><br>
<input type="submit" name="btnsubmit" class="btn">
<input type="submit" name="btnhomepage" value="Home Page" class="btn">
<?php
	if($_POST['btnsubmit'])
	{
		$ques=$_POST['txtQues'];
		$con=mysqli_connect('localhost','root','','php_project');
		$qry="insert into question(id,question) values(1,'".$ques."')";
		if(mysqli_query($con,$qry))
		{
			header("location:student_welcome.php");
		}
	}
	if(isset($_POST['btnhomepage']))
	{
		header("location:student_welcome.php");
	}
?>
</form>
</div>
</body>
</html>