<html>
<head>
	<title>notices</title>
</head>
<body>
    <div class="box"></div>
	<h1>See New Notices</h1>
	<table border="1" class="table">
		<tr>
			<th>Date</th>
			<th>Issued By</th>
			<th>Content</th>
		</tr>
		<?php
			session_start();
			$con1=mysqli_connect('localhost','root','','php_project');
            $qry1="select * from notice_id where id_of_receiver = 1";//.$SESSION['userid'];
            $rs1=mysqli_query($con1,$qry1);
            while($row=mysqli_fetch_array($rs1))
            {
            	echo "<tr>";
            	echo "<td><input type='text' name='txtDate' value='".$row['date_of_notice']."'></td>";
            	echo "<td><input type='text' name='txtIssuedBy' value='".$row['issued_by']."'></td>";
            	echo "<td><input type='text' name='txtContent' value='".$row['content']."'></td>";
            	echo "</tr>";
            }

            $con2=mysqli_connect('localhost','root','','php_project');
            $qry2="select * from notice_class,student_detail where class_of_receiver = class and id =1";//.$SESSION['userid'];
            $rs2=mysqli_query($con2,$qry2);
            while($row=mysqli_fetch_array($rs2))
            {
            	echo "<tr>";
            	echo "<td><input type='text' name='txtDate' value='".$row['date_of_notice']."'></td>";
            	echo "<td><input type='text' name='txtIssuedBy' value='".$row['issued_by']."'></td>";
            	echo "<td><input type='text' name='txtContent' value='".$row['content']."'></td>";
            	echo "</tr>";
            }

            $con3=mysqli_connect('localhost','root','','php_project');
            $qry3="select * from notice_semester, student_detail where student_detail.semester = notice_semester.semester and id = 1";//.$SESSION['userid'];
            $rs3=mysqli_query($con3,$qry3);
            while($row=mysqli_fetch_array($rs3))
            {
            	echo "<tr>";
            	echo "<td><input type='text' name='txtDate' value='".$row['date_of_notice']."'></td>";
            	echo "<td><input type='text' name='txtIssuedBy' value='".$row['issued_by']."'></td>";
            	echo "<td><input type='text' name='txtContent' value='".$row['content']."'></td>";
            	echo "</tr>";
            }
		?>
	</table>
</body>
</html>